from .base import Datatype

from .Categorical import Categorical
from .Float import Float
from .Integer import Integer
from .Nominal import Nominal
from .Ordinal import Ordinal
