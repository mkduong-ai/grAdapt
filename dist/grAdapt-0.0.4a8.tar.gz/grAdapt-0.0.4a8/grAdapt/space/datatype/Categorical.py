# Python Standard Libraries
import numpy as np

# grAdapt
from .Datatype import Datatype


class Categorical(Datatype):

    def __init__(self, list_str):
        """

        Parameters
        ----------
        list_str : list of strings
            Each string represents a category
        """

        self.len = len(list_str)
        self.container = [0, self.len-1]
        self.categories = list_str
        self.dtype = 'categorical'

    def __len__(self):
        return self.len

    def __getitem__(self, key):
        return self.container[key]

    def __setitem__(self, key, value):
        self.container[key] = value

    def get_category(self, value):
        key = int(np.round(value))
        return self.categories[key]

    def transform(self, x):
        """

        Parameters
        ----------
        x : numeric

        Returns
        -------
        numeric

        """
        return np.round(x)
