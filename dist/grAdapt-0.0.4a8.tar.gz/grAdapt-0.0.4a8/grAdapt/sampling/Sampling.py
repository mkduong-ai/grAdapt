# decorators
from abc import abstractmethod

class Sampling:
    """Base class for Sampling Methods

    """
    def __init__(self, bounds):
        self.bounds = bounds

    @abstractmethod
    def __call__(self, size=1):
        raise NotImplementedError