import scipy.linalg
import numpy as np


def inv_stable(A):
    """Inverts a positive semi-definite matrix A (stable)
    Adds a small positive definite matrix and uses cholesky decomposition.

    Parameters
    ----------
    A : positive semi-definite matrix (n, n)

    Returns
    -------
    An approximate inverse positive definite matrix (n, n)
    """
    not_2d = len(A.shape) != 2
    try:
        not_quadratic = A.shape[0] != A.shape[1]
    except:
        not_quadratic = True
    if not_2d or not_quadratic:
        raise Exception('Given Matrix is either not 2D or quadratic.')
    else:
        # make A positive definite for the triangulation
        Id = np.eye(A.shape[0])
        P = Id * 1e-7
        A_tilde = A + P
        # triangulate matrix with cholesky
        L = scipy.linalg.cholesky(A_tilde, lower=True)
        L_inv = scipy.linalg.solve_triangular(L, Id, lower=True)
        A_tilde_inv = L_inv.T @ L_inv

        return A_tilde_inv
