import numpy as np


def random_starts(n_calls, dim):
    """Returns the number of random_starts which should be made
    Parameters
    ----------
    n_calls : number of iterations
    dim : number of dimensions of the function

    Returns
    -------
    numeric

    """
    fraction = 0.5 * (1 - (1 / np.log(n_calls + 1))) * (1 - 1 / np.log(dim + 1))
    return max(1, int(n_calls * fraction))


def epochs(iteration):
    return min(100, int(iteration ** 1.25))