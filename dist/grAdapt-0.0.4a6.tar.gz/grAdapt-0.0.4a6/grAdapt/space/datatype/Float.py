# Python Standard Libraries
import numpy as np

# grAdapt
from .Datatype import Datatype


class Float(Datatype):

    def __init__(self, low, high, distribution='uniform'):
        """

        Parameters
        ----------
        low: numeric
        high: numeric
        """
        self.low = low
        self.high = high
        self.distribution = distribution
        self.container = [low, high]
        self.len = 2
        self.dtype = 'float'

    def __len__(self):
        return self.len

    def __getitem__(self, key):
        return self.container[key]

    def __setitem__(self, key, value):
        self.container[key] = value

    def transform(self, x):
        """

        Parameters
        ----------
        x : numeric

        Returns
        -------
        numeric

        """
        return x
