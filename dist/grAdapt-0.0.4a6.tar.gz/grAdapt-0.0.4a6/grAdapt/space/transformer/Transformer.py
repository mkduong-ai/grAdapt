# Python Standard Libraries
import numpy as np

# decorators
from abc import abstractmethod

# grAdapt


class Transformer:

    def __init__(self, func, bounds, distribution='uniform'):
        """

        Parameters
        ----------
        func : function to transform the input
        bounds : list of Datatype's
        """
        self.func = func
        self.bounds = bounds

    def __call__(self, x):
        """

        Parameters
        ----------
        x : array-like (d, )

        Returns
        -------

        """
        x_transformed = np.zeros_like(x)
        for i in range(x.shape[0]):
            try:
                x_transformed[i] = self.bounds[i].transform(x)
            except:
                x_transformed[i] = x[i]
        return self.func(x_transformed)
