# Python Standard Libraries
from itertools import product

# Third party imports
import numpy as np
# from numba import jit

from grAdapt.utils.math.spatial import pairwise_distances

# TODO: Use sample corner bounds
def sample_corner_bounds(bounds):
    """Samples points on the corner

    Parameters
    ----------
    bounds : list of tuples.
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]

    Returns
    -------
    array (2**len(bounds), len(bounds))
    """
    return np.array(list(product(bounds)), dtype=np.float)


def sample_points_bounds_init(bounds, n=1):
    """Samples corner points if n is big enough

    Parameters
    ----------
    bounds : list of tuples.
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]
    n : integer
        Describes the number of points which should be sampled from the given
        bound.

    Returns
    -------
    array (n, len(bounds))
    """
    if n > (2 ** len(bounds)):
        init = sample_corner_bounds(bounds)
        random = sample_points_bounds(bounds, n - (2 ** len(bounds)))

        return np.vstack((init, random))
    else:
        return sample_points_bounds(bounds, n)


def sample_points_bounds(bounds, n=1, sampling_method='loguniformNot'):
    """Random sample points uniformly given bounds

    Parameters
    ----------
    bounds : list of tuples.
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]
    n : integer
        Describes the number of points which should be sampled from the given
        bound.
    sampling_method : string (default = 'loguniform')
        A string for the sampling distribution.
        Currently only loguniform or uniform distribution supported.

    Returns
    -------
    sampled_points : array-like (n, dim)
        Returns a 2D array. dim is the dimension of a single point
        Each row corresponds to a single point.
        Each column corresponds to a dimension.
    """
    dim = len(bounds)
    sampled_points = np.empty((n, dim))
    for j in range(dim):
        sampled_points[:, j] = np.random.uniform(bounds[j][0], bounds[j][1], (n,))

    return sampled_points


def sample_points_max_min_delta(bounds, n=1, q=None):
    """Maximum minimal epsilon margin sampling method

    A fixed amount of points are candidates. The candidate is chosen
    as a point if it has the highest minimal epsilon margin among
    other points. The minimal epsilon margin is the smallest distance
    between two points. Each point has an minimal epsilon margin.
    For a better performance, only a fixed amount of latest points
    are considered.
    Has a disadvantage: creates 'evil' neighbours.

    Parameters
    ----------
    bounds : list of tuples.
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]
    n : integer
        number of points to be created
    q : array-like (n, dim)
        n points of dim dimensions

    Returns
    -------
    p : array-like (n, dim)
        Returns a 2D array. dim is the dimension of a single point
        Each row corresponds to a single point.
        Each column corresponds to a dimension.
    """

    start = 0
    if q is None:
        q = sample_points_bounds(bounds, 1)
        q_list = list(q)
        start = 1
    else:
        q_list = list(q)

    for i in range(start, n):

        if i >= 500:
            # shuffle not needed because points
            # are already random
            q_sublist = list(np.array(q_list[-500:]))
        else:
            q_sublist = q_list

        p = sample_points_bounds(bounds, 10)
        dists_matrix = pairwise_distances(p, np.array(q_sublist))
        epsilons = np.min(dists_matrix, axis=1)
        max_min_epsilon = np.argmax(epsilons)
        q_list.append(p[max_min_epsilon])

    return np.array(q_list)[-n:]


def sample_points_reassign(bounds, n=1, q=None):
    """Reassignment sampling method (slowest method)

    n Points are initially uniformly sampled given the bounds. The point
    with the smallest distance to another is being resampled uniformly.
    Avoids 'evil neighbours' but is slowest.
    For a better performance: Sliding window has been added.

    Parameters
    ----------
    bounds : list of tuples
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]
    n : integer
        number of points to be created
    q : array-like (n, dim)
        n points of dim dimensions

    Returns
    -------
    qp : array-like (n, dim)
        Returns a 2D array. dim is the dimension of a single point
        Each row corresponds to a single point.
        Each column corresponds to a dimension.
    """

    start = 0
    n_improvements = 500
    if n >= 500:
        window_size = 500
    else:
        window_size = n
    if q is None:
        q = sample_points_bounds(bounds, 1).reshape(1, -1)
        start = 1
    p = sample_points_bounds(bounds, n - 1)
    qp = np.vstack((q, p))
    for i in range(start, n_improvements):
        dists_matrix = pairwise_distances(qp[-window_size:], qp[-window_size:])
        np.fill_diagonal(dists_matrix, np.inf)
        idx_min_eps = np.argmin(np.min(dists_matrix, axis=1))
        qp[-window_size:][idx_min_eps] = sample_points_bounds(bounds, 1)

    return qp[-n:]


def sample_points_density(bounds, n=1, q=None, eps='auto'):
    """Random sample points given bounds

    Parameters
    ----------
    bounds : list of tuples
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]
    n : integer
        number of points to be created
    q : array-like (n, dim)
        n points of dim dimensions
    eps : numeric
        radius of hypersphere

    Returns
    -------
    p : array-like (n, dim)
        Returns a 2D array. dim is the dimension of a single point
        Each row corresponds to a single point.
        Each column corresponds to a dimension.
    """
    start = 0
    if q is None:
        q_list = list(sample_points_bounds(bounds, 1))
        start = 1
    else:
        q_list = list(q)

    if eps == 'auto':
        eps = 1 / 25 * np.max(np.array(list(map(bounds_range, bounds))))
        # auto decrease

    for i in range(start, n):

        if i >= 100:
            q_sublist = list(np.array(q_list[-100:]))
        else:
            q_sublist = q_list

        p = sample_points_bounds(bounds, 3)
        dists_matrix = pairwise_distances(p, np.array(q_sublist))
        clusters = dists_matrix < eps  # cluster for every point in p
        clusters_size = np.sum(clusters, axis=1)  # calc size for each cluster
        # first point tends to be empty already (stochastic)
        if clusters_size[0] == 0:
            q_list.append(p[0])
        else:
            smallest_cluster_idx = np.argmin(clusters_size)
            q_list.append(p[smallest_cluster_idx])  # add to current points

    return np.array(q_list)[-n:]


# @jit(nopython=True)
def inside_bounds(bounds, x_next):
    """Checks whether the point x_next is inside of bounds

    Parameters
    ----------
    bounds : list of tuples
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]
    x_next : array_like (d, )


    Returns
    -------
    boolean

    """
    n = len(bounds)
    for i in range(n):
        if not (bounds[i][0] <= x_next[i] <= bounds[i][1]):
            return False

    return True


def bounds_range(bounds_tuple):
    """Returns the range of a single bound
    Parameters
    ----------
    bounds_tuple : tuple object

    Returns
    -------
    numeric
    """
    return np.abs(bounds_tuple[1] - bounds_tuple[0])


def bounds_range_ndim(bounds):
    """Returns the range of a single bound
    Parameters
    ----------
    bounds : list of tuples
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]

    Returns
    -------
    array-like of shape (len(bounds),)
    """
    return np.array(list(map(bounds_range, bounds)))