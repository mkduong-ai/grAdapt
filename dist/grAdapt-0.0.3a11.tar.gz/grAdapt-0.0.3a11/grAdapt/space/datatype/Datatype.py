import numpy as np

class Datatype:

    def __init__(self):
        pass