import numpy as np
import matplotlib.pyplot as plt
from sklearn.gaussian_process import GaussianProcessRegressor
from scipy.stats import loguniform


def sample_points_bounds(bounds, n=1):
    # bounds: [(1, 2), (2, 3), (-1, 4)...]

    dim = len(bounds)
    out = np.zeros((n, dim))
    for i in range(n):
        for j in range(dim):
            # logUniform
            # out[i, j] = loguniform.rvs(bounds[j][0], bounds[j][1])
            # out[i, j] = np.power(10, np.random.uniform(bounds[j][0], bounds[j][1]))
            out[i, j] = np.random.uniform(bounds[j][0], bounds[j][1])

    return out


def inside_bounds(bounds, x_next):
    # bounds: [(1, 2), (2, 3), (-1, 4)...]
    # x_next: (d, )

    n = len(bounds)
    for i in range(n):
        if not (bounds[i][0] <= x_next[i] <= bounds[i][1]):
            return False

    return True


def f_gradient(x_test, x_train, gpr):
    # x_test: single data point shape (d,)
    # x_train: whole training data shape (m, d)
    # gpr: sklearn.gaussian_process.GaussianProcessRegressor object#
    # return: np array (d, )

    kernel_matrix = gpr.kernel_(x_test.reshape(1, -1), x_train)
    length_scale = gpr.kernel_.k2.length_scale
    n, m = kernel_matrix.shape[0], kernel_matrix.shape[1]
    d = x_test.shape[0]
    x_test = x_test.reshape(1, -1)

    grad = np.zeros(d)
    # calculate gradient
    for k in range(d):
        tmp_kernel = np.copy(kernel_matrix)
        for j in range(m):
            tmp_kernel[0, j] = ((x_train[j, k] - x_test[0, k]) * tmp_kernel[0, j]) / (length_scale ** 2)

        grad[k] = tmp_kernel.dot(gpr.alpha_)

    return grad  # shape (d, )


def gradient_descent(x0, x_train, num_iters, gpr, params=[1e-3]):
    # params: [learning rate]
    # x0 (d, )
    # x_train (n, d)
    # num_iters integer
    # gpr scikit gpr object

    alpha = params[0]

    x_next = x0
    for i in range(num_iters):
        grad = f_gradient(x_next, x_train, gpr)  # grad has shape (d, )
        x_next_prev = x_next
        x_next = x_next - alpha * grad
        '''
        if((x_next == x_next_prev).all()): # convergence test
            return x_next
        '''
        if (np.linalg.norm(x_next - x_next_prev)) < 1e-3:
            return x_next
    return x_next


def adam(x0, x_train, num_iters, gpr, params=[1e-3, 0.9, 0.999, 1e-8]):
    alpha = params[0]
    beta_1 = params[1]
    beta_2 = params[2]
    epsilon = params[3]
    m_t = 0
    v_t = 0
    x_next = x0

    for t in range(1, num_iters + 1):
        g_t = f_gradient(x_next, x_train, gpr)
        m_t = beta_1 * m_t + (1 - beta_1) * g_t
        v_t = beta_2 * v_t + (1 - beta_2) * (g_t * g_t)
        m_cap = m_t / (1 - (beta_1 ** t))
        v_cap = v_t / (1 - (beta_2 ** t))
        x_next = x_next - (alpha * m_cap) / (np.sqrt(v_cap) + epsilon)  # update step

    return x_next


def calc_cov1(bounds, gpr):
    bounds_vec = np.array([np.abs(bound[0] - bound[1]) for bound in
                           bounds])  # create 1d-array of distances between the upper and lower bound
    bounds_vec = bounds_vec * 1 / (np.log(iteration))  # shrink region to discover
    cov_matrix = np.zeros((dim, dim))
    return bounds_vec


def escape_function(x_train, y_train, bounds, gpr, iteration):
    # ignore warnings
    # numerical issues
    import warnings
    warnings.filterwarnings("ignore")

    dim = x_train[0].shape[0]  # dimension of space
    x_best = x_train[np.argmin(y_train)]  # x_best is current optimizer and "trust region"
    # Covariance Matrix alternatives
    # cov_matrix = np.eye(dim)
    # cov_matrix = np.eye(dim)*dim # allow wider exploration with the increase of the dimension
    bounds_vec = np.array([np.abs(bound[0] - bound[1]) for bound in
                           bounds])  # create 1d-array of distances between the upper and lower bound
    # delta to ensure that bounds_vec is not zero
    bounds_vec = (bounds_vec * 1 + 1e-14) / (2 * (np.log(iteration)))  # shrink region to discover
    # bounds_vec = (bounds_vec*1+1e-14)/iteration # new
    cov_matrix = np.zeros((dim, dim))
    np.fill_diagonal(cov_matrix, bounds_vec)  # fill cov matrix with the |upper_bound-lower_bound|

    best_point = None
    best_std = 0

    # Many points created near current best x point
    # Pick the one where the standard deviation is highest
    for i in range(max(3, 2 * x_train.shape[1])):

        current_point = np.random.multivariate_normal(x_best, cov_matrix)  # (d, )
        _, current_std = gpr.predict(current_point.reshape(1, -1), return_std=True)

        for i in range(10):
            if i == 9:
                current_point = sample_points_bounds(bounds, n=1).reshape(-1)  # (d, )
                _, current_std = gpr.predict(current_point.reshape(1, -1), return_std=True)

            if not (inside_bounds(bounds, current_point)):
                current_point = np.random.multivariate_normal(x_best, cov_matrix)
                _, current_std = gpr.predict(current_point.reshape(1, -1), return_std=True)

            if inside_bounds(bounds, current_point):
                break

        if current_std > best_std or current_std == 0:
            best_point = current_point

    x_next = best_point
    return x_next


# Multidimensional
# log uniform
def minimize(func, bounds, n_calls=100, x0=None, optimizer=adam, eps=1e-3, random_state=None,
             n_random_starts=10):
    # func: callable, returns a scalar
    # x0: shape (d, )
    # bounds: list of (min, max) e.g. [(1, 2), (3, 4), (-1, 2)]

    # count escape times
    escaped_num = 0

    # set seed if given
    if random_state != None:
        np.random.seed(random_state)

    if x0 == None:
        x0 = sample_points_bounds(bounds, 1)[0]

    if n_random_starts < 3:
        raise Exception('n_random_starts should be equal or greater than 3')

    if n_calls < n_random_starts:
        raise Exception('n_calls should be higher than n_random_starts')

    # randomly guess n_random_starts points
    initPoints = sample_points_bounds(bounds, n_random_starts - 1)
    x_train = np.append(initPoints, x0.reshape(1, -1), axis=0)
    y_train = []

    # evaluate func at each x_train[i]
    for i in range(x_train.shape[0]):
        y_train.append(func(x_train[i]))

    y_train = np.array(y_train)
    iteration = n_random_starts
    x_next = x0
    dim = x0.shape[0]  # dimension of space

    # Fit on initial points
    gpr = GaussianProcessRegressor()

    while iteration < n_calls:

        # Fit on GP
        gpr.fit(x_train, y_train)

        # call optimizer
        x_old = x_next
        x_next = optimizer(x_next, x_train, min(200, int(iteration ** (1.25))), gpr)  # (d, )

        # escape1 = x_next in x_train # point already known # escape 2 already handles it
        escape2 = (np.linalg.norm(x_old - x_next)) < eps  # x convergence
        escape3 = not (inside_bounds(bounds, x_next))  # check whether point is inside bounds
        escape_boolean = escape2 or escape3

        # sample new point if must escape or bounds not valid
        if escape_boolean:
            x_next = escape_function(x_train, y_train, bounds, gpr, iteration)
            escaped_num += 1

        # create new Training data
        x_train = np.append(x_train, x_next.reshape(1, -1), axis=0)
        y_train = np.append(y_train, func(x_next))

        # count iterator
        iteration = iteration + 1

        # print status
        print_string1 = '{:.2%} progress'.format(iteration / n_calls) + '\n'
        print_string2 = 'Escaped ' + str(escaped_num) + " times."
        print_string = print_string1 + print_string2
        # print(print_string, end='\r')
        print('{:.2%} progress'.format(iteration / n_calls), end='\r')
        print('Escaped ' + str(escaped_num) + " times.", end='\r')
        # print(str(np.round(iteration/n_calls, 4)*100)+' done.', end="\r")

        '''
        # y convergence
        if np.linalg.norm(y_train[-1]-y_train[-2]) < eps:
            x_next = escape_function(x_train, y_train, bounds, gpr, iteration)
            
            # create new Training data
            x_train = np.append(x_train, x_next.reshape(1, -1), axis=0)
            y_train = np.append(y_train, func(x_next))
            
            # count iterator
            iteration = iteration + 1
            
            if iteration == num_iters:
                return x_train, y_train, gpr
        '''

    print(escaped_num)
    return x_train, y_train, gpr


# TODO: Escape function anpassen?
def maximize(func, bounds, n_calls=100, x0=None, optimizer=adam, eps=1e-3, random_state=None,
             n_random_starts=10):
    def f_max(x):
        return -func(x)

    x, y, g = minimize(f_max, bounds, n_calls, x0, optimizer, eps, random_state,
                       n_random_starts)

    return x, -y, g
