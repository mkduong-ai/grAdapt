import numpy as np
# TODO: FIX LOG UNIFORM OR REPLACE IT WITH ANOTHER SAMPLING METHOD
# TODO: NEGATIVE LOG UNIFORM
# TODO: Structure? multiple files?
from scipy.stats import loguniform


def sample_points_bounds(bounds, n=1, sampling_method='loguniformNot', random_state=None):
    """Random sample points given bounds
    
    Parameters
    ----------
    bounds : list of tuples
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]
    n : integer
        Describes the number of points which should be sampled from the given
        bound.
    sampling_method : string (default = 'loguniform')
        A string for the sampling distribution.
        Currently only loguniform or uniform distribution supported.
    random_state : integer
        random_state integer sets numpy seed
    
    Returns
    -------
    sampled_points : array-like (n, dim)
        Returns a 2D array. dim is the dimension of a single point
        Each row corresponds to a single point.
        Each column corresponds to a dimension.
    """
    if random_state is not None:
        np.random.seed(random_state)

    dim = len(bounds)
    sampled_points = np.empty((n, dim))
    for i in range(n):
        for j in range(dim):
            if sampling_method == 'loguniform':
                sampled_points[i, j] = loguniform.rvs(bounds[j][0], bounds[j][1])
            else:
                sampled_points[i, j] = np.random.uniform(bounds[j][0], bounds[j][1])

    return sampled_points


def inside_bounds(bounds, x_next):
    """Checks whether the point x_next is inside of bounds
    
    Parameters
    ----------
    bounds : list of tuples
        Each tuple in the list defines the bounds for the corresponding variable
        Example: [(1, 2), (2, 3), (-1, 4)...]
    x_next : array_like (d, )
    
    
    Returns
    -------
    boolean
        
    """
    n = len(bounds)
    for i in range(n):
        if not (bounds[i][0] <= x_next[i] <= bounds[i][1]):
            return False

    return True


def random_starts(n_calls, dim):
    """Returns the number of random_starts which should be made
    Parameters
    ----------
    n_calls : number of iterations
    dim : number of dimensions of the function

    Returns
    -------
    numeric

    """
    fraction = 0.5 * (1 - (1 / np.log(n_calls + 1))) * (1 - 1 / np.log(dim + 1))
    return max(1, int(n_calls * fraction))


def epochs(iteration):
    return min(100, int(iteration ** 1.25))