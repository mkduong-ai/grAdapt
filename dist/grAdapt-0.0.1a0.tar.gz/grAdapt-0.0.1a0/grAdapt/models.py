# Python Standard Libraries
import warnings
import time
import os

# Third party imports
# fancy prints
import numpy as np
from tqdm import tqdm

# grAdapt package
from grAdapt import surrogate as sur, optimizer as opt, exploitation
from .utils import utils

# TODO: Layer System (Sequential Model)
# TODO: A base class for creating optimizers
# TODO: Add finite differences to derive derivatives
# TODO: or any different method to approximate the gradients
# TODO: Python Installation Module-
# TODO GPR ALONE ALPHA LOOK SINGLE POINTS
# TODO: Exploitation rework
# TODO: GPR Eval gradient? Eval on X = Training


class Sequential:

    def __init__(self, surrogate=sur.GPR(), optimizer=opt.ADAMBisection, exploit=exploitation.MultivariateNormalDistribution,
                 training=None):
        """
        :param surrogate: surrogate object
        :param optimizer: optimizer object
        :param exploit: exploitation object
        :param training: (X, y) with X shape (n, m) and y shape (n,)
        """
        """
        if surrogate is None:
            self.surrogate = sur.GPR()
        else:
            self.surrogate = surrogate
        """
        self.surrogate = surrogate
        self.optimizer = optimizer(self.surrogate)
        # optimizer is later initialized
        self.exploit = exploit(self.surrogate)

        # continue optimizing
        self.training = training
        if training is not None:
            self.X = training[0]
            self.y = training[1]
            self.fit(self.X, self.y)

    def warn_n_calls(self):
        if self.n_calls <= 0:
            raise Exception("Please set n_calls higher higher than 0.")

        if self.n_calls <= self.dim:
            warnings.warn("n_calls should be higher than the dimension of the problem.")

        if self.n_random_starts == 'auto' or not isinstance(self.n_random_starts, (int, float)):
            self.n_random_starts = utils.random_starts(self.n_calls, self.dim)

        if self.n_calls < self.n_random_starts:
            warnings.warn("n_random starts can't be higher than n_calls.")
            warnings.warn("n_random_starts set automatically. ")
            self.n_random_starts = utils.random_starts(self.n_calls, self.dim)

    def fit(self, X, y):
        """ Fit known points on surrogate model
        :param X: array-like (n, m)
        :param y: array (n,)
        :return: None
        """
        print("Surrogate model fitting on known points.")
        self.surrogate.fit(X, y)

    def minimize(self, func, bounds, n_calls=100, eps=1e-3, n_random_starts='auto',
                 random_state=None, auto_checkpoint=False, sliding_window=0, gradient_eval=True):
        self.func = func
        self.bounds = bounds
        self.n_calls = n_calls
        self.eps = eps
        self.n_random_starts = n_random_starts
        self.random_state = random_state
        self.dim = len(bounds)

        """Change surrogate model if dimension is high
        """
        if len(self.bounds) > 10:
            self.surrogate = sur.RBFRegression()
            self.optimizer = self.optimizer(self.surrogate)
            self.exploit = self.exploit(self.surrogate)

        """Catching errors/displaying warnings related to n_calls and n_random_starts
        and automatically set n_random_starts if not given
        """
        self.warn_n_calls()

        """set seed if given
        """
        if random_state is not None:
            np.random.seed(self.random_state)
        else:
            np.random.seed(1)

        """checkpoint print directory
        """
        if auto_checkpoint:
            directory_path = os.getcwd()+'/checkpoints'
            print("auto_checkpoint set to True. The training directory is located at\n"+directory_path)

        """Inittialize x_train and y_train
        Check whether training can be continued
        """
        x_train = np.empty((self.n_calls, self.dim))
        y_train = np.empty((self.n_calls,))
        if self.training is not None:
            x_train = np.vstack((self.X, x_train))
            y_train = np.hstack((self.y, y_train))
            print("Training data added successfully.")

        """Randomly guess n_random_starts points
        """
        print("Sampling "+ str(self.n_random_starts) +" random points.")
        print("Observe function values from random points. This might take a while.")
        train_len = len(y_train)-self.n_calls
        x_train[train_len:self.n_random_starts+train_len] = utils.sample_points_bounds(self.bounds, self.n_random_starts)
        y_train[train_len:self.n_random_starts+train_len] = np.array(list(map(func, x_train[:self.n_random_starts])))
        print("Finding optimum...")

        """Optimizing loop
        """
        start_time = time.perf_counter()
        for iteration in tqdm(range(self.n_random_starts+train_len, self.n_calls+train_len)):

            # Fit data on surrogate model
            self.surrogate.fit(x_train[:iteration], y_train[:iteration])

            # gradient parameters specific for the surrogate model
            surrogate_grad_params = [x_train[:iteration]]
            x_train[iteration] = self.optimizer.run(x_train[iteration - 1], utils.epochs(iteration),
                                                    surrogate_grad_params)

            # convergence check
            escape2 = (np.linalg.norm(x_train[iteration - 1] - x_train[iteration])) < self.eps  # x convergence
            escape3 = not (utils.inside_bounds(bounds, x_train[iteration]))  # check whether point is inside bounds
            escape_boolean = escape2 or escape3

            # sample new point if must escape or bounds not valid
            if escape_boolean:
                x_train[iteration] = self.exploit.get_point(x_train[:iteration], y_train[:iteration], iteration, bounds)

            # obtain y_train
            y_train[iteration] = func(x_train[iteration])

            # auto_checkpoint
            if auto_checkpoint and time.perf_counter() - start_time >= 60:
                self.save_checkpoint(x_train, y_train)
                start_time = time.perf_counter()

        if auto_checkpoint:
            self.save_checkpoint(x_train, y_train)

        return x_train, y_train, self.surrogate

    def maximize(self, func, bounds, **kwargs):
        def f_max(x):
            return -func(x)

        x_train, y_train, surrogate = self.minimize(f_max, bounds, **kwargs)

        return x_train, -y_train, surrogate

    def save_checkpoint(self, x_train, y_train):
        directory = os.getcwd()+'/checkpoints'
        filename = directory+'/checkpointXY'+time.strftime('%y%b%d-%H%M%S')+'.npz'

        if not os.path.exists(directory):
            os.makedirs(directory)

        np.savez(filename, x=x_train, y=y_train)
        print('Check point created under ' + filename)
