# Python Standard Libraries
# decorators
from abc import abstractmethod
from deprecated import deprecated

# Third party imports
import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF
from numba import njit

# TODO: Find better regression method which works on higher dimensions


class Surrogate:
    """Surrogate model object for the regression
       
       Parameters
       ----------
       model : Regression model object
            Can be a scikit-learn object. It must support
                .fit(X, y)
                .predict(X, return_std) (maybe?)
            
       surrogate_params : list or tuple
            parameters passed for the surrogate_model
       

       Attributes
       ----------
       self.model : model
       self.surrogate_params : surrogate_params


       Examples
       --------
       >>> surrogate = Surrogate(surrogate_params)
       >>> surrogate.fit(X, y)
       >>> surrogate.eval_gradient(x, surrogate_grad_params)
    """

    def __init__(self, model, surrogate_params):
        self.model = model
        self.surrogate_params = surrogate_params

    @abstractmethod
    def fit(self, X, y):
        """ Fits x points to the y-coordinate
        
            Parameters
            ----------
            X : array-like of size (n, m) for n points of d dimensions
            y : array-like of shape (n_samples,)
            
            
            Returns
            -------
            None
        """
        # self.model.fit(X, y)
        raise NotImplemented

    @abstractmethod
    def predict(self, X, **args):
        return NotImplementedError

    @abstractmethod
    def eval_gradient(self, x, surrogate_grad_params):
        """Evaluates the gradient of the surrogate model at point x
        
        Parameters
        ----------
        x : 1D array-like
        
        
        Returns
        -------
        grad : 1D array-like
            same shape as x
        """

        raise NotImplementedError


class GPR(Surrogate):
    """Gaussian Process Regression surrogate
    """

    def __init__(self, **surrogate_params):
        # if surrogate_params is None:
        #    surrogate_params = {'kernel': RBF}
        super().__init__(GaussianProcessRegressor(**surrogate_params), surrogate_params)

    def fit(self, X, y):
        if len(X.shape) == 1:
            X = X.reshape(-1, 1)
        self.model.fit(X, y)

    def predict(self, X, **args):
        if len(X.shape) == 1:
            X = X.reshape(-1, 1)
        return self.model.predict(X, **args)

    @deprecated("This function is deprecated. The gradient evaluation is not vectorized.")
    def eval_gradient_old(self, x, surrogate_grad_params):
        """Evaluates the gradient of GPR at point x
        Parameters
        ----------
        x: 1D array-like (d,)
        surrogate_grad_params: list
            surrogate_grad_params[0]: whole training data shape (m, d)
            
            
        Returns
        -------
        grad : 1D array-like
            same shape as x
        """

        x_train = surrogate_grad_params[0]
        x = x.reshape(1, -1)
        kernel_matrix = self.model.kernel_(x, x_train)
        length_scale = self.model.kernel_.k2.length_scale
        n, m = kernel_matrix.shape[0], kernel_matrix.shape[1]
        d = x.shape[1]

        grad = np.zeros(d)
        # calculate gradient
        for k in range(d):
            tmp_kernel = np.copy(kernel_matrix)
            for j in range(m):
                tmp_kernel[0, j] = ((x_train[j, k] - x[0, k]) * tmp_kernel[0, j]) / (length_scale ** 2)

            grad[k] = tmp_kernel.dot(self.model.alpha_)

        return grad

    def eval_gradient(self, x, surrogate_grad_params):
        """Evaluates the gradient of GPR at point x
                Parameters
                ----------
                x: 1D array-like (d,)
                surrogate_grad_params: list
                    surrogate_grad_params[0]: whole training data shape (m, d)


                Returns
                -------
                grad : 1D array-like
                    same shape as x
        """
        x_train = surrogate_grad_params[0]
        x = x.reshape(1, -1)
        kernel_matrix = self.model.kernel_(x, x_train)
        length_scale = self.model.kernel_.k2.length_scale
        n, m = kernel_matrix.shape[0], kernel_matrix.shape[1]
        d = x.shape[1]

        grad = np.zeros(d)
        # calculate gradient
        for k in range(d):
            tmp_kernel = np.copy(kernel_matrix)
            tmp_kernel[0, :] = ((x_train[:, k] - x[0, k]) * tmp_kernel[0, :]) / (length_scale ** 2)

            grad[k] = tmp_kernel.dot(self.model.alpha_)

        return grad


class RBFRegression(Surrogate):

    def __init__(self, **surrogate_params):
        super().__init__(None, surrogate_params)
        self.RBF = RBF()
        self.x_train = None
        self.alpha_ = None

    def fit(self, X, y):
        """Fit training data (X, y)
        Parameters
        ----------
        X : array-like (n, d)
        y : array-like (n,)


        Returns
        -------
        None

        """
        self.alpha_ = y

        if len(X.shape) == 1:
            self.x_train = X.reshape(-1, 1)
        else:
            self.x_train = X

    def predict(self, x_predict, return_std=False):
        """Predict y value based on x_predict
        Parameters
        ----------
        x_predict : array-like (n, d)
        return_std : array-like (n,)
            returns the standard deviation of the posterior mean


        Returns
        -------
        array-like (n,)

        """
        if len(x_predict.shape) == 1:
            x_predict = x_predict.reshape(-1, 1)
        return self.RBF(x_predict, self.x_train) @ self.alpha_

    def eval_gradient(self, x, surrogate_grad_params):
        """Evaluates the gradient of GPR at point x
        Parameters
        ----------
        x: 1D array-like (d,)
        surrogate_grad_params: list
            surrogate_grad_params[0]: whole training data shape (m, d)


        Returns
        -------
        grad : 1D array-like
            same shape as x
        """

        x_train = surrogate_grad_params[0]
        x = x.reshape(1, -1)
        kernel_matrix = self.RBF(x, x_train)
        length_scale = self.RBF.length_scale
        n, m = kernel_matrix.shape[0], kernel_matrix.shape[1]
        d = x.shape[1]

        grad = np.zeros(d)
        # calculate gradient
        for k in range(d):
            tmp_kernel = np.copy(kernel_matrix)
            tmp_kernel[0, :] = ((x_train[:, k] - x[0, k]) * tmp_kernel[0, :]) / (length_scale ** 2)

            grad[k] = tmp_kernel.dot(self.alpha_)

        return grad

    # TODO: Maybe approximate kernel in the future with Nystroem Method
    # TODO: Find best kernel. Try out non-stationary kernel functions
    def kernel_(self, x_test, x_train):
        """Call the kernel function
        Parameters
        ----------
        x_test : array-like (n, d)
        x_train : array-like (m, d)


        Returns
        -------
        array-like (n, m)
        """

        if len(x_test.shape) == 1:
            x_test = x_test.reshape(-1, 1)

        if len(x_train.shape) == 1:
            x_train = x_train.reshape(-1, 1)

        return self.RBF(x_test, x_train)
