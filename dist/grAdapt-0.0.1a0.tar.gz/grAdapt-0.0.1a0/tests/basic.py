from grAdapt.models import Sequential
import numpy as np
from time import time

def timer(function):
    def new_function():
        start_time = time()
        function()
        elapsed = time() - start_time
        print("Time elapsed: {time}".format(time=elapsed))
        #print('Function "{name}" took {time} seconds to complete.'.format(name=function.__name__, time=elapsed))
    return new_function()


def rastrigin(x):
    x = np.array(x)
    return 10*len(x)+np.sum(x**2-10*np.cos(2*np.pi*x), axis=0)

@timer
def test():
    model = Sequential()
    bounds = [(-10, 10) for i in range(10)]
    x, y, _ = model.minimize(rastrigin, bounds, 800)
    print("Minimum found: {ymin}".format(ymin=np.min(y)))
    print("Argmin: {xmin}".format(xmin=x[np.argmin(y)]))