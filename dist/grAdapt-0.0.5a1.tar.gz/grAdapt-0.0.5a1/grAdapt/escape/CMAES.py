# Python Standard Libraries
import numpy as np

# grAdapt package
from .Escape import Escape, inside_bounds, sample_points_bounds, bounds_range_ndim

# TODO
class CMAES(Escape):

    def __init__(self, surrogate):
        super().__init__(surrogate)

    def get_point(self, x_train, y_train, iteration, bounds):
        pass