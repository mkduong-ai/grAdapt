# Python Standard Libraries
import numpy as np

# grAdapt package
from .Escape import Escape, sample_points_bounds


class UniformDistribution(Escape):
    """Standard Multivariate Normal Distribution
    is added to the current best position

    """

    def __init__(self, surrogate):
        super().__init__(surrogate)

    def get_point(self, x_train, y_train, iteration, bounds):
        """
        Parameters
        ----------
        self : self object
        x_train : array-like shape (n, d)
        y_train : array-like shape (n,)
        iteration : integer
        bounds: list of 2-tuples

        Returns
        -------
        array-like (d,)
        """
        return sample_points_bounds(bounds, 1)
