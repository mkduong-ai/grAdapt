# Python Standard Libraries
import numpy as np
# decorators
from abc import abstractmethod

# grAdapt package
from grAdapt.utils.sampling import *

# TODO: Acquisition functions for exploitations
# TODO: REWORK Pass exploitation hyperparameters...
# TODO: sampling_method is being passed by
# TODO: Sampling methods considering training data


class Escape:
    """Escape Base class

    Parameters
    ----------
    self.surrogate : surrogate object

    Attributes
    ----------


    Examples
    --------
    """

    def __init__(self, surrogate):
        self.surrogate = surrogate
        self.sampling_method = sample_points_max_min_delta

    def __call__(self, surrogate):
        self.surrogate = surrogate

    @abstractmethod
    def get_point(self, x_train, y_train, iteration, bounds):
        return NotImplementedError

