# https://en.wikipedia.org/wiki/Test_functions_for_optimization

import numpy as np