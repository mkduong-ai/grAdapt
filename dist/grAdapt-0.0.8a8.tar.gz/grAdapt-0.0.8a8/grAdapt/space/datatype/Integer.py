# Python Standard Libraries
import numpy as np

# grAdapt
from .base import Datatype


class Integer(Datatype):
    """Integer Datatype
    Only the low and upper bound are required to define a Integer Datatype.

    >>> from grAdapt.space.datatype import Integer
    >>> first_dim = Integer(low=10, high=100)
    >>> bounds = [first_dim]
    """

    def __init__(self, low, high, distribution='uniform'):
        """

        Parameters
        ----------
        low: int
        high: int
        """

        # Exception handling
        if high < low:
            raise ValueError("high must be higher than low.")

        self.low = low
        self.high = high
        if self.low % 1 > 0 or self.high % 1 > 0:
            raise ValueError('low and high must be integers.')
        self.bound = [self.low, self.high]
        self.len = 2
        self.dtype = 'int'

    def __len__(self):
        return self.len

    def __getitem__(self, key):
        return self.bound[key]

    def __setitem__(self, key, value):
        self.bound[key] = value
    
    def get_value(self, value):
        return self.get_integer(value)
    
    def get_integer(self, value):
        return int(np.round(value))

    def transform(self, x):
        """Single value to transform

        Parameters
        ----------
        x : numeric

        Returns
        -------
        numeric

        """
        return np.round(x)
