# Python Standard Libraries
import numpy as np

# grAdapt
from .base import Datatype


class Float(Datatype):
    """Float Datatype
    Only the low and upper bound are required to define a Float Datatype.

    >>> from grAdapt.space.datatype import Float
    >>> first_dim = Float(low=10.5, high=20)
    >>> bounds = [first_dim]
    """

    def __init__(self, low, high, distribution='uniform'):
        """

        Parameters
        ----------
        low: numeric
        high: numeric
        """

        # Exception handling
        if high < low:
            raise ValueError("high must be higher than low.")

        self.low = low
        self.high = high
        self.distribution = distribution
        self.bound = [low, high]
        self.len = 2
        self.dtype = 'float'

    def __len__(self):
        return self.len

    def __getitem__(self, key):
        return self.bound[key]

    def __setitem__(self, key, value):
        self.bound[key] = value
    
    def get_value(self, value):
        return self.get_float()

    def get_float(self, value):
        return value

    def transform(self, x):
        """

        Parameters
        ----------
        x : numeric

        Returns
        -------
        numeric

        """
        return x
